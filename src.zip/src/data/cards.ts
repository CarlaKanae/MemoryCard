export const cards = [
    {
        id: '1',
        back: '../../public/images/anexo.jpeg',
    },
    {
        id: '2',
        back: '🍕',
    },
    {
        id: '3',
        back: '🥐',
    },
    {
        id: '4',
        back: '😒',
    },
    {
        id: '5',
        back: '💀',
    },
    {
        id: '6',
        back: '👻',
    },
    {
        id: '7',
        back: '🦖',
    },
    {
        id: '8',
        back: '🦊',
    },
    {
        id: '9',
        back: '😒',
    },
    {
        id: '10',
        back: '💀',
    },
    {
        id: '1',
        back: '👻',
    },
    {
        id: '12',
        back: '🦖',
    },
];